//
//  ScheduleAndResult.swift
//  kbo_3
//
//  Created by 구장회 on 2017. 5. 6..
//  Copyright © 2017년 구장회. All rights reserved.
//

import UIKit

class ScheduleAndResult: UINavigationItem {

}
